<?php

$fname= "localhost";
$Lnmae= "root";
$NID= "";
$Email= "";
$number= "";
$address= "";
$password = "";
$cpassword= "";

$db_name = "hornpolice";

$conn = mysqli_connect($sname, $unmae, $password, $db_name);

if (!$conn) {

    echo "Connection failed!";

}